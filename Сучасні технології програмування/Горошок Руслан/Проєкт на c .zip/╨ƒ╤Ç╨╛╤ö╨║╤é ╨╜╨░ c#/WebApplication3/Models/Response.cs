﻿namespace WebApplication3.Models
{
    public class Response
    {
        public int statusCode { get; set; }

        public string statusMessage { get; set; }
    }
}
