﻿namespace WebApplication3.Models
{
    public class Registration
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string PASS { get; set; }
        public string Email { get; set; }
        public int IsActive { get; set; }
    }
}
